package com.example.quizapp1

object Constants {

    const val USER_NAME: String = "user name"
    const val TOTAL_QUESTIONS: String = "total uestions"
    const val CORRECT_ANSWERS: String = "correct answers"

    fun getQuestion (): ArrayList<Question> {
        val questionsList = ArrayList<Question>()

        val q1 = Question (
            1,
            "What country does this flag belong to?",
             R.drawable.argentina,
            "Argentina",
            "Honduras",
            "Uruguay",
            "El Salvador",
            1)
        questionsList.add(q1)

        val q2 = Question (
            2,
            "What country does this flag belong to?",
            R.drawable.aland,
            "Norge",
            "Island",
            "Åland",
            "Färöarna",
            3)
        questionsList.add(q2)

        val q3 = Question (
            3,
            "What country does this flag belong to?",
        R.drawable.antarktis,
        "Grönland",
        "Antarktis",
        "Atlantis",
        "Belgien",
        2)
        questionsList.add(q3)

        val q4 = Question (
            4,
            "What country does this flag belong to?",
            R.drawable.australien,
            "Storbritannien",
            "Nya Zeeland",
            "Singapore",
            "Australien",
            4)
        questionsList.add(q4)

        val q5 = Question (
            5,
            "What country does this flag belong to?",
            R.drawable.albanien,
            "Andorra",
            "Armenien",
            "Albanien",
            "Georgien",
            3)
        questionsList.add(q5)

        val q6 = Question (
            6,
            "What country does this flag belong to?",
            R.drawable.angola,
            "Angola",
            "Kongo",
            "Tanzania",
            "Uganda",
            1)
        questionsList.add(q6)

        val q7 = Question (
            7,
            "What country does this flag belong to?",
            R.drawable.azerbaijan,
            "Uzbekistan",
            "Kazakstan",
            "Algeriet",
            "Azerbaijan",
            4)
        questionsList.add(q7)


        return questionsList
    }

}